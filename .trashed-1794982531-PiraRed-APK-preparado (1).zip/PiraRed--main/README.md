# PiraRed — compilación de APK

Este repositorio genera una APK de prueba mediante GitHub Actions.

## Cómo obtener la APK
1. Subí estos archivos a la raíz del repositorio de GitHub, reemplazando los archivos anteriores.
2. Abrí la pestaña **Actions** del repositorio.
3. Entrá al flujo **Crear APK PiraRed**. Se ejecuta automáticamente al hacer push a `main` o `master`; también se puede iniciar manualmente con **Run workflow**.
4. Esperá a que termine en verde y abrí la ejecución finalizada.
5. En **Artifacts**, descargá `PiraRed-APK-debug` y descomprimí el ZIP para encontrar el archivo `.apk`.
6. Pasá la APK al celular e instalala. Android puede pedir permiso para instalar desde esa fuente.

Esta APK es de depuración, no está firmada para publicación en Google Play. La app sigue siendo una demostración: no incluye cuentas, base de datos ni anuncios reales.
